# Chirag – portfolio + private workspace

Plain HTML/CSS/JS, no build step. Netlify: empty build command, publish directory `.`.

- `index.html` – public site (3D glass hero, loader, marquee, work, contact).
- `workspace.html` – private canvas workspace; opens in a new tab from the site. Sign in, then drag cards around, pan (scroll) and zoom (Ctrl+scroll). Every file shows a live preview (images, video, audio, PDF, text); select one to see a large preview and open, download or delete it. Add links from the left panel; drop files on the canvas to upload.
- `config.js` + `supabase.sql` – backend setup (see below).

## Supabase setup (once)
1. Create a free project at supabase.com.
2. SQL Editor -> New query -> paste `supabase.sql` -> Run.
3. Authentication -> Users -> Add user (tick Auto Confirm User). Then turn OFF "Allow new users to sign up".
4. Project Settings -> API: copy the Project URL and the legacy `anon` key (starts with `eyJ`) into `config.js`.
5. Push to GitHub; Netlify redeploys.

## Notes
- The `anon` key is public by design; your login and the rules in `supabase.sql` protect the data. Never use the `service_role` key here.
- Card positions are saved in the browser you use, not in Supabase, so the layout can differ per device.
- Free Supabase: 50 MB per file, 1 GB total, projects pause after about a week idle.

## 3D gallery images
The ring of panels on the homepage uses `images/p01.jpg` to `p20.jpg` (in order around the ring). Replace any file with your own image (same name, ideally under 300 KB) to change it. Some of the current images are other people's artwork or company wallpapers; make sure you have permission to show them publicly, or swap them.
