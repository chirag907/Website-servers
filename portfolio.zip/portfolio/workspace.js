(()=>{
const $=s=>document.querySelector(s),cfg=window.CONFIG||{},B='files';
const el=(t,p={},...k)=>{const e=Object.assign(document.createElement(t),p);e.append(...k);return e};
const sb=cfg.SUPABASE_URL&&cfg.SUPABASE_ANON_KEY&&window.supabase?supabase.createClient(cfg.SUPABASE_URL,cfg.SUPABASE_ANON_KEY):null;
let uid,items=[],selKey=null,filter='all',drag=null,view={x:60,y:60,k:1};
let pos={};try{pos=JSON.parse(localStorage.getItem('ws-pos')||'{}')}catch(e){}
const savePos=()=>{try{localStorage.setItem('ws-pos',JSON.stringify(pos))}catch(e){}};
const world=$('#world'),canvas=$('#canvas'),gmsg=$('#gate-msg');
const fmt=n=>n>1048576?(n/1048576).toFixed(1)+' MB':Math.max(1,Math.round((n||0)/1024))+' KB';

/* ---- sign in ---- */
if(!sb){gmsg.textContent='Not connected yet. Fill in config.js (see README).';$('#gate-btn').disabled=true}
else{
  sb.auth.getSession().then(({data})=>{if(data.session)start(data.session.user)});
  sb.auth.onAuthStateChange(ev=>{if(ev==='SIGNED_OUT')location.reload()});
}
$('#gate-form').addEventListener('submit',async e=>{
  e.preventDefault();if(!sb)return;gmsg.textContent='';
  const {data,error}=await sb.auth.signInWithPassword({email:$('#email').value.trim(),password:$('#pass').value});
  $('#pass').value='';
  if(error){gmsg.textContent='Sign-in failed: '+error.message;return}
  start(data.user);
});
$('#out').onclick=()=>sb.auth.signOut();
function start(u){uid=u.id;$('#gate').hidden=true;$('#app').hidden=false;apply();load()}

/* ---- data ---- */
async function load(){
  const [l,f]=await Promise.all([
    sb.from('links').select('id,title,url').order('created_at'),
    sb.storage.from(B).list(uid,{limit:500,sortBy:{column:'created_at',order:'asc'}})]);
  items=[...(l.data||[]).map(x=>({key:'l'+x.id,type:'link',id:x.id,name:x.title,url:x.url})),
    ...(f.data||[]).filter(x=>x.id).map(x=>({key:'f'+x.name,type:'file',path:uid+'/'+x.name,name:x.name.replace(/^\d+-/,''),size:x.metadata&&x.metadata.size,mime:(x.metadata&&x.metadata.mimetype)||''}))];
  items.forEach((it,i)=>{if(!pos[it.key])pos[it.key]={x:(i%4)*300,y:Math.floor(i/4)*300}});
  render();
}

/* ---- previews (used on cards and in the inspector) ---- */
async function signed(it,opts){
  const {data}=await sb.storage.from(B).createSignedUrl(it.path,3600,opts);return data&&data.signedUrl;
}
const ext=it=>(it.name.split('.').pop()||'').toLowerCase();
async function fill(box,it,big){
  if(it.type==='link'){box.textContent=it.url;return}
  const u=it.signed||(it.signed=await signed(it));
  if(!u){box.textContent='No preview';return}
  const x=ext(it),m=it.mime;
  if(m.startsWith('image/')||['png','jpg','jpeg','gif','webp','svg','avif'].includes(x))box.replaceChildren(el('img',{src:u,alt:it.name,loading:'lazy'}));
  else if(m.startsWith('video/')||['mp4','webm','mov'].includes(x))box.replaceChildren(el('video',{src:u,muted:true,controls:big,preload:'metadata'}));
  else if(m.startsWith('audio/')||['mp3','wav','ogg','m4a'].includes(x))box.replaceChildren(el('audio',{src:u,controls:true}));
  else if(m==='application/pdf'||x==='pdf')box.replaceChildren(el('iframe',{src:u+'#toolbar=0&view=FitH',title:it.name}));
  else if(m.startsWith('text/')||['txt','md','json','csv','js','py','html','css','xml','yml'].includes(x)){
    try{const t=await (await fetch(u)).text();box.replaceChildren(el('pre',{},t.slice(0,big?20000:500)))}catch(e){box.replaceChildren(el('span',{className:'badge'},x.toUpperCase()))}
  }else box.replaceChildren(el('span',{className:'badge'},(x||'file').toUpperCase()));
}

/* ---- render ---- */
function render(){
  world.innerHTML='';$('#layers').innerHTML='';
  items.filter(i=>filter==='all'||i.type===filter).forEach(it=>{
    const p=pos[it.key],pv=el('div',{className:'pv'},'…');
    const c=el('div',{className:'card '+it.type+(it.key===selKey?' sel':'')},el('h3',{},it.name),pv);
    c.dataset.key=it.key;c.style.transform=`translate(${p.x}px,${p.y}px)`;world.append(c);
    fill(pv,it,false);
    const b=el('button',{},it.name);b.onclick=()=>{select(it.key);focus(it)};
    $('#layers').append(el('li',{className:it.key===selKey?'on':''},b));
  });
}
function select(k){
  selKey=k;document.querySelectorAll('.card').forEach(c=>c.classList.toggle('sel',c.dataset.key===k));
  document.querySelectorAll('#layers li').forEach((li,i)=>li.classList.toggle('on',false));
  const it=items.find(i=>i.key===k),insp=$('#insp');insp.innerHTML='';
  if(!it){insp.append(el('p',{className:'muted'},'Select a file or link to preview it.'));return}
  const big=el('div',{className:'big'},'…'),acts=el('div',{className:'acts'});
  insp.append(el('h2',{},it.name),el('p',{className:'muted'},it.type==='file'?(it.mime||'file')+' · '+fmt(it.size):it.url),big,acts);
  fill(big,it,true);
  if(it.type==='link')acts.append(el('a',{href:it.url,target:'_blank',rel:'noopener noreferrer',textContent:'Open link'}));
  else{
    acts.append(el('button',{onclick:async()=>{const u=await signed(it);u&&window.open(u,'_blank','noopener')}},'Open'),
      el('button',{onclick:async()=>{const u=await signed(it,{download:it.name});u&&(location.href=u)}},'Download'));
  }
  acts.append(el('button',{onclick:async()=>{
    if(!confirm('Delete "'+it.name+'"?'))return;
    if(it.type==='file')await sb.storage.from(B).remove([it.path]);else await sb.from('links').delete().eq('id',it.id);
    selKey=null;await load();select(null)}},'Delete'));
}
function focus(it){const p=pos[it.key],r=canvas.getBoundingClientRect();view.x=r.width/2-(p.x+130)*view.k;view.y=r.height/2-(p.y+100)*view.k;apply()}

/* ---- pan / zoom / drag ---- */
function apply(){
  world.style.transform=`translate(${view.x}px,${view.y}px) scale(${view.k})`;
  $('#zoom').textContent=Math.round(view.k*100)+'%';
  canvas.style.backgroundPosition=`${view.x}px ${view.y}px`;canvas.style.backgroundSize=`${24*view.k}px ${24*view.k}px`;
}
canvas.addEventListener('wheel',e=>{
  e.preventDefault();
  if(e.ctrlKey||e.metaKey){
    const k=Math.min(2,Math.max(.2,view.k*Math.exp(-e.deltaY*.01))),r=canvas.getBoundingClientRect(),cx=e.clientX-r.left,cy=e.clientY-r.top;
    view.x=cx-(cx-view.x)*(k/view.k);view.y=cy-(cy-view.y)*(k/view.k);view.k=k;
  }else{view.x-=e.deltaX;view.y-=e.deltaY}
  apply();
},{passive:false});
canvas.addEventListener('pointerdown',e=>{
  if(e.target.closest('.hud'))return;
  const c=e.target.closest('.card');
  if(c){select(c.dataset.key);const p=pos[c.dataset.key];drag={c,sx:e.clientX,sy:e.clientY,ox:p.x,oy:p.y}}
  else{select(null);drag={pan:1,sx:e.clientX,sy:e.clientY,ox:view.x,oy:view.y}}
  canvas.setPointerCapture(e.pointerId);
});
canvas.addEventListener('pointermove',e=>{
  if(!drag)return;const dx=e.clientX-drag.sx,dy=e.clientY-drag.sy;
  if(drag.pan){view.x=drag.ox+dx;view.y=drag.oy+dy;apply()}
  else{const p=pos[drag.c.dataset.key];p.x=drag.ox+dx/view.k;p.y=drag.oy+dy/view.k;drag.c.style.transform=`translate(${p.x}px,${p.y}px)`}
});
const end=()=>{if(drag&&!drag.pan)savePos();drag=null};
canvas.addEventListener('pointerup',end);canvas.addEventListener('pointercancel',end);
$('#fit').onclick=()=>{view={x:60,y:60,k:1};apply()};
document.querySelectorAll('.seg button').forEach(b=>b.onclick=()=>{
  filter=b.dataset.f;document.querySelectorAll('.seg button').forEach(x=>x.setAttribute('aria-selected',x===b));render();
});

/* ---- add links and upload files ---- */
$('#link-form').addEventListener('submit',async e=>{
  e.preventDefault();const url=$('#l-url').value.trim();
  if(!/^https?:\/\//i.test(url))return;
  const {error}=await sb.from('links').insert({title:$('#l-title').value.trim(),url});
  if(error){alert('Could not save the link.');return}
  e.target.reset();load();
});
async function upload(list){
  for(const f of list){
    const {error}=await sb.storage.from(B).upload(uid+'/'+Date.now()+'-'+f.name.replace(/[^\w.\-]+/g,'_'),f);
    if(error)alert('Could not upload '+f.name+': '+error.message);
  }
  load();
}
$('#up-btn').onclick=()=>$('#file-in').click();
$('#file-in').onchange=e=>{upload(e.target.files);e.target.value=''};
canvas.addEventListener('dragover',e=>e.preventDefault());
canvas.addEventListener('drop',e=>{e.preventDefault();if(uid)upload(e.dataTransfer.files)});
})();
